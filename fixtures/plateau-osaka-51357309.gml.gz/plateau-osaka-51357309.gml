<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:gml="http://www.opengis.net/gml" xmlns:uro="https://www.geospatial.jp/iur/uro/3.2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.opengis.net/citygml/2.0 http://schemas.opengis.net/citygml/2.0/cityGMLBase.xsd http://www.opengis.net/citygml/profiles/base/2.0 http://schemas.opengis.net/citygml/profiles/base/2.0/CityGML.xsd https://www.geospatial.jp/iur/uro/3.2 ../../schemas/iur/uro/3.2/urbanObject.xsd https://www.geospatial.jp/iur/urf/3.2 ../../schemas/iur/urf/3.2/urbanFunction.xsd">
	<gml:boundedBy>
		<gml:Envelope srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
			<gml:lowerCorner>34.589634677118006 135.49873090106684 0</gml:lowerCorner>
			<gml:upperCorner>34.59176021058151 135.50006488875817 18.509999999999998</gml:upperCorner>
		</gml:Envelope>
	</gml:boundedBy>
	<core:cityObjectMember>
		<bldg:Building gml:id="bldg_c81bef9b-a841-43e5-86a2-ed108a2b7c36"><core:creationDate>2023-03-22</core:creationDate>
			<gen:measureAttribute name="計測周辺長"><gen:value uom="m">23.9839129335</gen:value>
			</gen:measureAttribute>
			<gen:intAttribute name="ユーザーID"><gen:value>100704</gen:value>
			</gen:intAttribute>
			<gen:intAttribute name="1/2500図郭"><gen:value>111</gen:value>
			</gen:intAttribute>
			<gen:stringAttribute name="区名"><gen:value>住吉区</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町丁目名称"><gen:value>山之内５丁目</gen:value>
			</gen:stringAttribute>
			<gen:intAttribute name="街区番号"><gen:value>5</gen:value>
			</gen:intAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">9.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:lod0FootPrint><gml:MultiSurface><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59153163228514 135.49907336764358 0 34.591548481254144 135.49916110979012 0 34.59158897606017 135.49914974737092 0 34.59157124258032 135.49905736650652 0 34.591545785868284 135.4990645070861 0 34.59154667938546 135.49906914570846 0 34.59153163228514 135.49907336764358 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0FootPrint>
			<bldg:lod1Solid><gml:Solid><gml:exterior><gml:CompositeSurface><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59153163228514 135.49907336764358 9.2444 34.59154667938546 135.49906914570846 9.2444 34.591545785868284 135.4990645070861 9.2444 34.59157124258032 135.49905736650652 9.2444 34.59158897606017 135.49914974737092 9.2444 34.591548481254144 135.49916110979012 9.2444 34.59153163228514 135.49907336764358 9.2444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59153163228514 135.49907336764358 9.2444 34.591548481254144 135.49916110979012 9.2444 34.591548481254144 135.49916110979012 18.509999999999998 34.59153163228514 135.49907336764358 18.509999999999998 34.59153163228514 135.49907336764358 9.2444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.591548481254144 135.49916110979012 9.2444 34.59158897606017 135.49914974737092 9.2444 34.59158897606017 135.49914974737092 18.509999999999998 34.591548481254144 135.49916110979012 18.509999999999998 34.591548481254144 135.49916110979012 9.2444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59158897606017 135.49914974737092 9.2444 34.59157124258032 135.49905736650652 9.2444 34.59157124258032 135.49905736650652 18.509999999999998 34.59158897606017 135.49914974737092 18.509999999999998 34.59158897606017 135.49914974737092 9.2444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59157124258032 135.49905736650652 9.2444 34.591545785868284 135.4990645070861 9.2444 34.591545785868284 135.4990645070861 18.509999999999998 34.59157124258032 135.49905736650652 18.509999999999998 34.59157124258032 135.49905736650652 9.2444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.591545785868284 135.4990645070861 9.2444 34.59154667938546 135.49906914570846 9.2444 34.59154667938546 135.49906914570846 18.509999999999998 34.591545785868284 135.4990645070861 18.509999999999998 34.591545785868284 135.4990645070861 9.2444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59154667938546 135.49906914570846 9.2444 34.59153163228514 135.49907336764358 9.2444 34.59153163228514 135.49907336764358 18.509999999999998 34.59154667938546 135.49906914570846 18.509999999999998 34.59154667938546 135.49906914570846 9.2444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59153163228514 135.49907336764358 18.509999999999998 34.591548481254144 135.49916110979012 18.509999999999998 34.59158897606017 135.49914974737092 18.509999999999998 34.59157124258032 135.49905736650652 18.509999999999998 34.591545785868284 135.4990645070861 18.509999999999998 34.59154667938546 135.49906914570846 18.509999999999998 34.59153163228514 135.49907336764358 18.509999999999998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<uro:buildingDetailAttribute><uro:BuildingDetailAttribute><uro:buildingRoofEdgeArea uom="m2">32.8710073772</uro:buildingRoofEdgeArea>
					<uro:buildingStructureType codeSpace="../../codelists/BuildingDetailAttribute_buildingStructureType.xml">601</uro:buildingStructureType>
					<uro:buildingStructureOrgType codeSpace="../../codelists/BuildingDetailAttribute_buildingStructureOrgType.xml">1</uro:buildingStructureOrgType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType><uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType><uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType><uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType><uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1110</uro:detailedUsage>
					<uro:groundFloorUsage codeSpace="../../codelists/BuildingDetailAttribute_groundFloorUsage.xml">9999</uro:groundFloorUsage>
					<uro:secondFloorUsage codeSpace="../../codelists/BuildingDetailAttribute_secondFloorUsage.xml">9999</uro:secondFloorUsage>
					<uro:thirdFloorUsage codeSpace="../../codelists/BuildingDetailAttribute_thirdFloorUsage.xml">9999</uro:thirdFloorUsage>
					<uro:basementFirstUsage codeSpace="../../codelists/BuildingDetailAttribute_basementFirstUsage.xml">9999</uro:basementFirstUsage>
					<uro:basementSecondUsage codeSpace="../../codelists/BuildingDetailAttribute_basementSecondUsage.xml">9999</uro:basementSecondUsage>
					<uro:specifiedBuildingCoverageRate>80</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>200</uro:specifiedFloorAreaRate><uro:surveyYear>2017</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:bldgDisasterRiskAttribute><uro:RiverFloodingRiskAttribute><uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">2</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.474</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">1</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
					<uro:duration uom="hour">0</uro:duration>
				</uro:RiverFloodingRiskAttribute>
			</uro:bldgDisasterRiskAttribute>
			<uro:buildingIDAttribute><uro:BuildingIDAttribute><uro:buildingID>27100-bldg-26726</uro:buildingID>
					<uro:branchID>1</uro:branchID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">27</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">27120</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:bldgDataQualityAttribute><uro:DataQualityAttribute><uro:geometrySrcDescLod0 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">000</uro:geometrySrcDescLod0>
					<uro:geometrySrcDescLod1 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">000</uro:geometrySrcDescLod1>
					<uro:geometrySrcDescLod2 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">999</uro:geometrySrcDescLod2>
					<uro:geometrySrcDescLod3 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">999</uro:geometrySrcDescLod3>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">000</uro:thematicSrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">100</uro:thematicSrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">201</uro:thematicSrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">400</uro:thematicSrcDesc>
					<uro:appearanceSrcDescLod2 codeSpace="../../codelists/DataQualityAttribute_appearanceSrcDesc.xml">99</uro:appearanceSrcDescLod2>
					<uro:appearanceSrcDescLod3 codeSpace="../../codelists/DataQualityAttribute_appearanceSrcDesc.xml">99</uro:appearanceSrcDescLod3>
					<uro:lod1HeightType codeSpace="../../codelists/DataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:publicSurveyDataQualityAttribute><uro:PublicSurveyDataQualityAttribute><uro:srcScaleLod0 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_srcScale.xml">1</uro:srcScaleLod0>
							<uro:srcScaleLod1 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_srcScale.xml">1</uro:srcScaleLod1>
							<uro:publicSurveySrcDescLod0 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_geometrySrcDesc.xml">023</uro:publicSurveySrcDescLod0>
							<uro:publicSurveySrcDescLod1 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_geometrySrcDesc.xml">023</uro:publicSurveySrcDescLod1>
						</uro:PublicSurveyDataQualityAttribute>
					</uro:publicSurveyDataQualityAttribute>
				</uro:DataQualityAttribute>
			</uro:bldgDataQualityAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">27120</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">12009205</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">9999</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">9999</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1110</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">1110</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">9999</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember><core:cityObjectMember>
		<bldg:Building gml:id="bldg_29c10102-3c0e-41f3-9e0e-be15359b944a"><core:creationDate>2023-03-22</core:creationDate>
			<gen:measureAttribute name="計測周辺長"><gen:value uom="m">20.295706276</gen:value>
			</gen:measureAttribute>
			<gen:intAttribute name="ユーザーID"><gen:value>100720</gen:value>
			</gen:intAttribute>
			<gen:intAttribute name="1/2500図郭"><gen:value>111</gen:value>
			</gen:intAttribute>
			<gen:stringAttribute name="区名"><gen:value>住吉区</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町丁目名称"><gen:value>山之内５丁目</gen:value>
			</gen:stringAttribute>
			<gen:intAttribute name="街区番号"><gen:value>3</gen:value>
			</gen:intAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">6.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:lod0FootPrint><gml:MultiSurface><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59129546078734 135.49984269747006 0 34.59134044641972 135.499820625183 0 34.59132675636571 135.49977982718156 0 34.591275020662565 135.49980466527694 0 34.59129096445774 135.49984544975112 0 34.59129546078734 135.49984269747006 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0FootPrint>
			<bldg:lod1Solid><gml:Solid><gml:exterior><gml:CompositeSurface><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59129546078734 135.49984269747006 9.2211 34.59129096445774 135.49984544975112 9.2211 34.591275020662565 135.49980466527694 9.2211 34.59132675636571 135.49977982718156 9.2211 34.59134044641972 135.499820625183 9.2211 34.59129546078734 135.49984269747006 9.2211</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59129546078734 135.49984269747006 9.2211 34.59134044641972 135.499820625183 9.2211 34.59134044641972 135.499820625183 15.71 34.59129546078734 135.49984269747006 15.71 34.59129546078734 135.49984269747006 9.2211</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59134044641972 135.499820625183 9.2211 34.59132675636571 135.49977982718156 9.2211 34.59132675636571 135.49977982718156 15.71 34.59134044641972 135.499820625183 15.71 34.59134044641972 135.499820625183 9.2211</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59132675636571 135.49977982718156 9.2211 34.591275020662565 135.49980466527694 9.2211 34.591275020662565 135.49980466527694 15.71 34.59132675636571 135.49977982718156 15.71 34.59132675636571 135.49977982718156 9.2211</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.591275020662565 135.49980466527694 9.2211 34.59129096445774 135.49984544975112 9.2211 34.59129096445774 135.49984544975112 15.71 34.591275020662565 135.49980466527694 15.71 34.591275020662565 135.49980466527694 9.2211</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59129096445774 135.49984544975112 9.2211 34.59129546078734 135.49984269747006 9.2211 34.59129546078734 135.49984269747006 15.71 34.59129096445774 135.49984544975112 15.71 34.59129096445774 135.49984544975112 9.2211</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59129546078734 135.49984269747006 15.71 34.59134044641972 135.499820625183 15.71 34.59132675636571 135.49977982718156 15.71 34.591275020662565 135.49980466527694 15.71 34.59129096445774 135.49984544975112 15.71 34.59129546078734 135.49984269747006 15.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<uro:buildingDetailAttribute><uro:BuildingDetailAttribute><uro:buildingRoofEdgeArea uom="m2">24.6247124951</uro:buildingRoofEdgeArea>
					<uro:buildingStructureType codeSpace="../../codelists/BuildingDetailAttribute_buildingStructureType.xml">601</uro:buildingStructureType>
					<uro:buildingStructureOrgType codeSpace="../../codelists/BuildingDetailAttribute_buildingStructureOrgType.xml">1</uro:buildingStructureOrgType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType><uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType><uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType><uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType><uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1110</uro:detailedUsage>
					<uro:groundFloorUsage codeSpace="../../codelists/BuildingDetailAttribute_groundFloorUsage.xml">9999</uro:groundFloorUsage>
					<uro:secondFloorUsage codeSpace="../../codelists/BuildingDetailAttribute_secondFloorUsage.xml">9999</uro:secondFloorUsage>
					<uro:thirdFloorUsage codeSpace="../../codelists/BuildingDetailAttribute_thirdFloorUsage.xml">9999</uro:thirdFloorUsage>
					<uro:basementFirstUsage codeSpace="../../codelists/BuildingDetailAttribute_basementFirstUsage.xml">9999</uro:basementFirstUsage>
					<uro:basementSecondUsage codeSpace="../../codelists/BuildingDetailAttribute_basementSecondUsage.xml">9999</uro:basementSecondUsage>
					<uro:specifiedBuildingCoverageRate>80</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>200</uro:specifiedFloorAreaRate><uro:surveyYear>2017</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingIDAttribute><uro:BuildingIDAttribute><uro:buildingID>27100-bldg-26788</uro:buildingID>
					<uro:branchID>1</uro:branchID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">27</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">27120</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:bldgDataQualityAttribute><uro:DataQualityAttribute><uro:geometrySrcDescLod0 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">000</uro:geometrySrcDescLod0>
					<uro:geometrySrcDescLod1 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">000</uro:geometrySrcDescLod1>
					<uro:geometrySrcDescLod2 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">999</uro:geometrySrcDescLod2>
					<uro:geometrySrcDescLod3 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">999</uro:geometrySrcDescLod3>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">000</uro:thematicSrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">100</uro:thematicSrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">201</uro:thematicSrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">400</uro:thematicSrcDesc>
					<uro:appearanceSrcDescLod2 codeSpace="../../codelists/DataQualityAttribute_appearanceSrcDesc.xml">99</uro:appearanceSrcDescLod2>
					<uro:appearanceSrcDescLod3 codeSpace="../../codelists/DataQualityAttribute_appearanceSrcDesc.xml">99</uro:appearanceSrcDescLod3>
					<uro:lod1HeightType codeSpace="../../codelists/DataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:publicSurveyDataQualityAttribute><uro:PublicSurveyDataQualityAttribute><uro:srcScaleLod0 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_srcScale.xml">1</uro:srcScaleLod0>
							<uro:srcScaleLod1 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_srcScale.xml">1</uro:srcScaleLod1>
							<uro:publicSurveySrcDescLod0 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_geometrySrcDesc.xml">023</uro:publicSurveySrcDescLod0>
							<uro:publicSurveySrcDescLod1 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_geometrySrcDesc.xml">023</uro:publicSurveySrcDescLod1>
						</uro:PublicSurveyDataQualityAttribute>
					</uro:publicSurveyDataQualityAttribute>
				</uro:DataQualityAttribute>
			</uro:bldgDataQualityAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">27120</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">12009205</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">9999</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">9999</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1110</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">1110</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">9999</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember><core:cityObjectMember>
		<bldg:Building gml:id="bldg_d253ad04-b500-40cd-9e0e-273645ed74a5"><core:creationDate>2023-03-22</core:creationDate>
			<gen:measureAttribute name="計測周辺長"><gen:value uom="m">25.8564471663</gen:value>
			</gen:measureAttribute>
			<gen:intAttribute name="ユーザーID"><gen:value>100719</gen:value>
			</gen:intAttribute>
			<gen:intAttribute name="1/2500図郭"><gen:value>111</gen:value>
			</gen:intAttribute>
			<gen:stringAttribute name="区名"><gen:value>住吉区</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町丁目名称"><gen:value>山之内５丁目</gen:value>
			</gen:stringAttribute>
			<gen:intAttribute name="街区番号"><gen:value>3</gen:value>
			</gen:intAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">431</bldg:usage>
			<bldg:measuredHeight uom="m">-9999</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:lod0FootPrint><gml:MultiSurface><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59129546078734 135.49984269747006 0 34.591309161988924 135.49988622073582 0 34.59130467682678 135.49989169828385 0 34.5913183110052 135.49991886994678 0 34.5913587779841 135.4998940994336 0 34.591356468391936 135.49988048658582 0 34.59136096472227 135.49987773430445 0 34.59134044641972 135.499820625183 0 34.59129546078734 135.49984269747006 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0FootPrint>
			<bldg:lod1Solid><gml:Solid><gml:exterior><gml:CompositeSurface><gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59129546078734 135.49984269747006 9.4742 34.59134044641972 135.499820625183 9.4742 34.59136096472227 135.49987773430445 9.4742 34.591356468391936 135.49988048658582 9.4742 34.5913587779841 135.4998940994336 9.4742 34.5913183110052 135.49991886994678 9.4742 34.59130467682678 135.49989169828385 9.4742 34.591309161988924 135.49988622073582 9.4742 34.59129546078734 135.49984269747006 9.4742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59129546078734 135.49984269747006 9.4742 34.591309161988924 135.49988622073582 9.4742 34.591309161988924 135.49988622073582 12.4742 34.59129546078734 135.49984269747006 12.4742 34.59129546078734 135.49984269747006 9.4742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.591309161988924 135.49988622073582 9.4742 34.59130467682678 135.49989169828385 9.4742 34.59130467682678 135.49989169828385 12.4742 34.591309161988924 135.49988622073582 12.4742 34.591309161988924 135.49988622073582 9.4742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59130467682678 135.49989169828385 9.4742 34.5913183110052 135.49991886994678 9.4742 34.5913183110052 135.49991886994678 12.4742 34.59130467682678 135.49989169828385 12.4742 34.59130467682678 135.49989169828385 9.4742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.5913183110052 135.49991886994678 9.4742 34.5913587779841 135.4998940994336 9.4742 34.5913587779841 135.4998940994336 12.4742 34.5913183110052 135.49991886994678 12.4742 34.5913183110052 135.49991886994678 9.4742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.5913587779841 135.4998940994336 9.4742 34.591356468391936 135.49988048658582 9.4742 34.591356468391936 135.49988048658582 12.4742 34.5913587779841 135.4998940994336 12.4742 34.5913587779841 135.4998940994336 9.4742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.591356468391936 135.49988048658582 9.4742 34.59136096472227 135.49987773430445 9.4742 34.59136096472227 135.49987773430445 12.4742 34.591356468391936 135.49988048658582 12.4742 34.591356468391936 135.49988048658582 9.4742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59136096472227 135.49987773430445 9.4742 34.59134044641972 135.499820625183 9.4742 34.59134044641972 135.499820625183 12.4742 34.59136096472227 135.49987773430445 12.4742 34.59136096472227 135.49987773430445 9.4742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59134044641972 135.499820625183 9.4742 34.59129546078734 135.49984269747006 9.4742 34.59129546078734 135.49984269747006 12.4742 34.59134044641972 135.499820625183 12.4742 34.59134044641972 135.499820625183 9.4742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember><gml:Polygon><gml:exterior><gml:LinearRing><gml:posList>34.59129546078734 135.49984269747006 12.4742 34.591309161988924 135.49988622073582 12.4742 34.59130467682678 135.49989169828385 12.4742 34.5913183110052 135.49991886994678 12.4742 34.5913587779841 135.4998940994336 12.4742 34.591356468391936 135.49988048658582 12.4742 34.59136096472227 135.49987773430445 12.4742 34.59134044641972 135.499820625183 12.4742 34.59129546078734 135.49984269747006 12.4742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<uro:buildingDetailAttribute><uro:BuildingDetailAttribute><uro:buildingRoofEdgeArea uom="m2">40.1873624977</uro:buildingRoofEdgeArea>
					<uro:buildingStructureType codeSpace="../../codelists/BuildingDetailAttribute_buildingStructureType.xml">610</uro:buildingStructureType>
					<uro:buildingStructureOrgType codeSpace="../../codelists/BuildingDetailAttribute_buildingStructureOrgType.xml">2</uro:buildingStructureOrgType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType><uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType><uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType><uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType><uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1740</uro:detailedUsage>
					<uro:groundFloorUsage codeSpace="../../codelists/BuildingDetailAttribute_groundFloorUsage.xml">9999</uro:groundFloorUsage>
					<uro:secondFloorUsage codeSpace="../../codelists/BuildingDetailAttribute_secondFloorUsage.xml">9999</uro:secondFloorUsage>
					<uro:thirdFloorUsage codeSpace="../../codelists/BuildingDetailAttribute_thirdFloorUsage.xml">9999</uro:thirdFloorUsage>
					<uro:basementFirstUsage codeSpace="../../codelists/BuildingDetailAttribute_basementFirstUsage.xml">9999</uro:basementFirstUsage>
					<uro:basementSecondUsage codeSpace="../../codelists/BuildingDetailAttribute_basementSecondUsage.xml">9999</uro:basementSecondUsage>
					<uro:specifiedBuildingCoverageRate>80</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>200</uro:specifiedFloorAreaRate><uro:surveyYear>2017</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingIDAttribute><uro:BuildingIDAttribute><uro:buildingID>27100-bldg-26782</uro:buildingID>
					<uro:branchID>1</uro:branchID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">27</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">27120</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:bldgDataQualityAttribute><uro:DataQualityAttribute><uro:geometrySrcDescLod0 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">000</uro:geometrySrcDescLod0>
					<uro:geometrySrcDescLod1 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">000</uro:geometrySrcDescLod1>
					<uro:geometrySrcDescLod2 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">999</uro:geometrySrcDescLod2>
					<uro:geometrySrcDescLod3 codeSpace="../../codelists/DataQualityAttribute_geometrySrcDesc.xml">999</uro:geometrySrcDescLod3>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">000</uro:thematicSrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">100</uro:thematicSrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">201</uro:thematicSrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/DataQualityAttribute_thematicSrcDesc.xml">400</uro:thematicSrcDesc>
					<uro:appearanceSrcDescLod2 codeSpace="../../codelists/DataQualityAttribute_appearanceSrcDesc.xml">99</uro:appearanceSrcDescLod2>
					<uro:appearanceSrcDescLod3 codeSpace="../../codelists/DataQualityAttribute_appearanceSrcDesc.xml">99</uro:appearanceSrcDescLod3>
					<uro:lod1HeightType codeSpace="../../codelists/DataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:publicSurveyDataQualityAttribute><uro:PublicSurveyDataQualityAttribute><uro:srcScaleLod0 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_srcScale.xml">1</uro:srcScaleLod0>
							<uro:srcScaleLod1 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_srcScale.xml">1</uro:srcScaleLod1>
							<uro:publicSurveySrcDescLod0 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_geometrySrcDesc.xml">023</uro:publicSurveySrcDescLod0>
							<uro:publicSurveySrcDescLod1 codeSpace="../../codelists/PublicSurveyDataQualityAttribute_geometrySrcDesc.xml">023</uro:publicSurveySrcDescLod1>
						</uro:PublicSurveyDataQualityAttribute>
					</uro:publicSurveyDataQualityAttribute>
				</uro:DataQualityAttribute>
			</uro:bldgDataQualityAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">27120</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">12009205</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">9999</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">9999</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1740</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">9999</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
			<uro:bldgKeyValuePairAttribute><uro:KeyValuePairAttribute><uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">9999</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:bldgKeyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>
